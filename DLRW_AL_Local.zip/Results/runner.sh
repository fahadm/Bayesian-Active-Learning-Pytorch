#!/bin/sh
python DLRW_New.py BALD
python DLRW_New.py VAR_RATIOS
python DLRW_New.py MAX_ENTROPY
python DLRW_New.py MEAN_STD
python DLRW_New.py RANDOM

